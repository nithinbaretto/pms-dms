import type { RefObject } from 'react';
import nomineeFormSvgPaths from '../../../../assets/figma-svg/svg-2tncnp7dy5';
import emailOtpSvgPaths from '../../../../assets/figma-svg/svg-ftc9bj5bhu';
import imgEmptyNominee from '../../../../assets/icons/svg/empty_nominee_icon.svg';
import { Checkbox } from '../../../../shared/ui/checkbox';
import { Input } from '../../../../shared/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../../../shared/ui/select';
import OnboardingStepFooter from '../../components/OnboardingStepFooter';
import { useOnboardingStore } from '../../state/onboarding-store';
import { NOMINEE_NAME_MAX_LENGTH, PROOF_NUMBER_MAX_LENGTH, PROOF_NUMBER_PLACEHOLDERS, PROOF_OF_IDENTITY_OPTIONS, RELATIONSHIP_OPTIONS } from './constants';
import { getDobDayOptions, getDobMonthOptions, getDobYearOptions } from './helpers';

interface NomineeDetailsScreenProps {
  // Nominee form state
  nomineeOption: 'later' | 'now';
  setNomineeOption: (option: 'later' | 'now') => void;
  nomineeName: string;
  setNomineeName: (name: string) => void;
  nomineeRelationship: string;
  setNomineeRelationship: (relationship: string) => void;
  nomineeProofType: string;
  setNomineeProofType: (type: string) => void;
  nomineeProofNumber: string;
  setNomineeProofNumber: (number: string) => void;
  nomineeMobileCountry: string;
  nomineeMobile: string;
  setNomineeMobile: (mobile: string) => void;
  nomineeEmail: string;
  setNomineeEmail: (email: string) => void;
  nomineeIsMinor: 'yes' | 'no';
  nomineeDob: string;
  nomineeAddress: string;

  // Guardian details
  guardianName: string;
  setGuardianName: (name: string) => void;
  guardianAddress: string;
  sameAsNomineeAddress: boolean;
  onSameAsNomineeAddressChange: (same: boolean) => void;

  // Dropdown state
  showProofDropdown: boolean;
  setShowProofDropdown: (show: boolean) => void;
  proofDropdownRef: RefObject<HTMLDivElement | null>;
  proofDropdownMobileRef: RefObject<HTMLDivElement | null>;

  // DOB picker modal
  showDobPicker: boolean;
  dobPickerAnimating: boolean;
  selectedDay: string;
  setSelectedDay: (day: string) => void;
  selectedMonth: string;
  setSelectedMonth: (month: string) => void;
  selectedYear: string;
  setSelectedYear: (year: string) => void;
  handleOpenDobPicker: () => void;
  handleCloseDobPicker: () => void;
  handleSaveDob: () => void;

  handleOpenNomineeAddressModal: () => void;
  handleOpenGuardianAddressModal: () => void;

  // Navigation
  isEditMode: boolean;
  isTransitioning: boolean;
  canProceed: boolean;
  setIsTransitioning: (transitioning: boolean) => void;
  setCurrentStep: (step: string) => void;
  setIsEditMode: (editMode: boolean) => void;
}

const SELECT_MENU_CLASS =
  "z-[70] max-h-[200px] overflow-y-scroll rounded-[8px] border border-[#eee] bg-white p-0 shadow-[4px_4px_20px_0px_rgba(0,0,0,0.12)] [scrollbar-width:thin] [scrollbar-color:#c5cdd6_transparent] [&::-webkit-scrollbar]:w-[6px] [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-[#c5cdd6] [&_[data-slot=select-scroll-up-button]]:hidden [&_[data-slot=select-scroll-down-button]]:hidden [&_[data-radix-select-viewport]]:h-auto [&_[data-radix-select-viewport]]:max-h-none";

function RelationshipField({
  value,
  onChange,
  className,
}: {
  value: string;
  onChange: (value: string) => void;
  className?: string;
}) {
  return (
    <div className={`flex flex-col gap-[4px] flex-1 min-w-[310px] ${className ?? ""}`}>
      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
        <p className="text-[#231F20]">Relationship with Applicant</p>
        <p className="text-[#E8402F]">*</p>
      </div>
      <Select value={value || undefined} onValueChange={onChange}>
        <SelectTrigger className="h-[36px] w-full rounded-[8px] border border-[#eee] bg-white px-[14px] font-['Mulish',sans-serif] text-[13px] font-normal text-[#231f20] shadow-none outline-none focus-visible:border-[var(--color-onboarding-primary)] focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] data-[placeholder]:text-[#71859b] [&_svg]:size-[10px] [&_svg]:opacity-100 [&_svg]:text-[#231F20]">
          <SelectValue placeholder="Select Relationship with Applicant" />
        </SelectTrigger>
        <SelectContent position="popper" className={SELECT_MENU_CLASS}>
          {RELATIONSHIP_OPTIONS.map((relationship) => (
            <SelectItem
              key={relationship}
              value={relationship}
              className="cursor-pointer py-2 font-['Mulish',sans-serif] text-[13px] text-[#231f20] focus:bg-[#f5f5f5] focus:text-[#231f20]"
            >
              {relationship}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

function DobSelect({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <div className="flex-1 flex flex-col gap-[8px]">
      <label className="font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal text-[#231F20]">
        {label}
      </label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-[40px] w-full rounded-[8px] border border-[#eee] bg-white px-[12px] font-['Mulish',sans-serif] text-[13px] font-normal text-[#231f20] shadow-none outline-none focus-visible:border-[var(--color-onboarding-primary)] focus-visible:ring-0 [&_svg]:size-[10px] [&_svg]:opacity-100 [&_svg]:text-[#5A6B7D]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent position="popper" className={SELECT_MENU_CLASS}>
          {options.map((option) => (
            <SelectItem
              key={option}
              value={option}
              className="cursor-pointer py-2 font-['Mulish',sans-serif] text-[13px] text-[#231f20] focus:bg-[#f3f4f6] focus:text-[#231f20]"
            >
              {option}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}

export function NomineeDetailsScreen({
  nomineeOption,
  setNomineeOption,
  nomineeName,
  setNomineeName,
  nomineeRelationship,
  setNomineeRelationship,
  nomineeProofType,
  setNomineeProofType,
  nomineeProofNumber,
  setNomineeProofNumber,
  nomineeMobileCountry,
  nomineeMobile,
  setNomineeMobile,
  nomineeEmail,
  setNomineeEmail,
  nomineeIsMinor,
  nomineeDob,
  nomineeAddress,
  guardianName,
  setGuardianName,
  guardianAddress,
  sameAsNomineeAddress,
  onSameAsNomineeAddressChange,
  showProofDropdown,
  setShowProofDropdown,
  proofDropdownRef,
  proofDropdownMobileRef,
  showDobPicker,
  dobPickerAnimating,
  selectedDay,
  setSelectedDay,
  selectedMonth,
  setSelectedMonth,
  selectedYear,
  setSelectedYear,
  handleOpenDobPicker,
  handleCloseDobPicker,
  handleSaveDob,
  handleOpenNomineeAddressModal,
  handleOpenGuardianAddressModal,
  isEditMode,
  isTransitioning,
  canProceed,
  setIsTransitioning,
  setCurrentStep,
  setIsEditMode,
}: NomineeDetailsScreenProps) {
  const currentFlow = useOnboardingStore((state) => state.currentFlow);
  const onboardingMethod = useOnboardingStore((state) => state.onboardingMethod);
  const isAifManualFlow = currentFlow === 'aif-individual' && onboardingMethod === 'MANUAL';
  const detailsSourceLabel = currentFlow.startsWith('aif-') ? 'AMFI' : 'APMI';
  const fetchedDetailsSubtitle = isAifManualFlow
    ? 'Please enter the details below to continue.'
    : `Your details have been fetched from ${detailsSourceLabel}. Fields shown in grey cannot be changed`;
  const proofTypeKey = nomineeProofType as keyof typeof PROOF_NUMBER_PLACEHOLDERS;
  const proofNumberPlaceholder = PROOF_NUMBER_PLACEHOLDERS[proofTypeKey] ?? 'Enter Proof Number';
  const proofNumberMaxLength = PROOF_NUMBER_MAX_LENGTH[proofTypeKey];
  const isAadhaarProof = nomineeProofType === 'Aadhar';

  return (
    <>
      {/* Desktop View */}
      <div className="hidden lg:block">
        <div className="mx-auto flex w-full max-w-[1240px] flex-col gap-[24px]">
            {/* Header */}
            <div className="flex flex-col gap-[4px]">
              <p className="font-['Mulish',sans-serif] font-medium leading-[33px] text-[#231f20] text-[22px]">Nominee Details</p>
              <p className="font-['Mulish',sans-serif] font-normal leading-[22.5px] text-[#435160] text-[15px]">{fetchedDetailsSubtitle}</p>
            </div>

            {/* Form Container */}
            <div className="flex flex-col gap-[8px]">
            {/* Step Progress */}
            <div className="flex items-center justify-between font-['Mulish',sans-serif] font-normal leading-[18px] text-[#231f20] text-[12px]">
              <p>Step 4 of 6</p>
              <p>60%</p>
            </div>

            {/* White Card - Content hugs, no internal scroll */}
            <div className="w-full overflow-visible rounded-[16px] bg-white shadow-[0px_0px_12px_0px_rgba(0,0,0,0.06)]">
              {/* Progress Bar - Full width at top */}
              <div className="h-2 w-full overflow-hidden rounded-t-[16px] bg-[#e6e7e8]">
                <div className="h-full w-[60%] rounded-r-full bg-[#37b400]" />
              </div>

              <div className="flex flex-col gap-[20px] p-[16px]">
                {/* Switcher */}
                <div className="flex items-start w-full">
                  <div className="bg-[#f5f5f5] rounded-[16777200px] p-[4px] flex gap-[4px]">
                    <button
                      onClick={() => setNomineeOption('later')}
                      className={`px-[14px] py-[5px] rounded-[16777200px] border border-transparent transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0 ${
                        nomineeOption === 'later' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                      }`}
                    >
                      <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Add Nominee Later</p>
                    </button>
                    <button
                      onClick={() => setNomineeOption('now')}
                      className={`px-[14px] py-[5px] rounded-[16777200px] border border-transparent transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0 ${
                        nomineeOption === 'now' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                      }`}
                    >
                      <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Add Nominee now</p>
                    </button>
                  </div>
                </div>

                {/* Content Area - No scroll, hugs content */}
                {nomineeOption === 'later' ? (
                  /* Empty State */
                  <div className="flex flex-col items-center justify-center py-[24px] gap-[12px]">
                    <img src={imgEmptyNominee} alt="No nominee added" className="w-[108px] h-[66px] object-contain" />
                    <p className="font-['Mulish',sans-serif] font-normal leading-none text-[#71859B] text-[14px] text-center tracking-[0px]">Add a nominee now for convenience or complete this step later.</p>
                  </div>
                ) : (
                  /* Nominee Form */
                  <div className="flex flex-wrap gap-[16px]">
                    {/* Nominee Name */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Nominee Name</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <Input
                        type="text"
                        value={nomineeName}
                        onChange={(e) => setNomineeName(e.target.value)}
                        placeholder="Enter Nominee Name"
                        maxLength={NOMINEE_NAME_MAX_LENGTH}
                        autoComplete="name"
                        inputMode="text"
                      />
                    </div>

                    <RelationshipField
                      value={nomineeRelationship}
                      onChange={setNomineeRelationship}
                      className="max-w-[calc(33.333%-11px)]"
                    />

                    {/* Proof of Identity */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)] relative" ref={proofDropdownRef}>
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Proof of Identity</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <div className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative flex items-center focus-within:border-[var(--color-onboarding-primary)] focus-within:ring-2 focus-within:ring-[rgba(147,22,30,0.2)]">
                        <button
                          onClick={() => setShowProofDropdown(!showProofDropdown)}
                          tabIndex={-1}
                          className="bg-[#f5f5f5] flex gap-[4px] items-center px-[6px] h-full outline-none hover:bg-[#e8e8e8] transition-colors focus-visible:outline-none rounded-l-[8px]"
                        >
                          <p className="font-['Mulish',sans-serif] font-normal text-[13px] text-[#71859b]">{nomineeProofType}</p>
                          <svg className="h-[10px] w-[10px]" fill="none" viewBox="0 0 8.62789 4.87783">
                            <path d={nomineeFormSvgPaths.p3ea1e500} fill="#5A6B7D" />
                          </svg>
                        </button>
                        <Input
                          type="text"
                          value={nomineeProofNumber}
                          onChange={(e) => setNomineeProofNumber(e.target.value)}
                          placeholder={proofNumberPlaceholder}
                          maxLength={proofNumberMaxLength}
                          inputMode={isAadhaarProof ? 'numeric' : 'text'}
                          autoCapitalize={isAadhaarProof ? 'off' : 'characters'}
                          className={`h-full flex-1 border-0 bg-transparent px-[12px] shadow-none focus-visible:border-transparent focus-visible:ring-0 ${isAadhaarProof ? '' : 'uppercase'}`}
                        />
                      </div>

                      {/* Dropdown Menu */}
                      {showProofDropdown && (
                        <div
                          className="absolute top-[calc(100%+4px)] left-0 right-0 bg-white rounded-[8px] border border-[#e5e5e6] z-[60] overflow-hidden shadow-lg"
                          onMouseDown={(event) => event.stopPropagation()}
                        >
                          {PROOF_OF_IDENTITY_OPTIONS.map((proofType) => (
                            <button
                              key={proofType}
                              onClick={() => {
                                setNomineeProofType(proofType);
                                setShowProofDropdown(false);
                              }}
                              className="content-stretch w-full flex gap-[8px] h-[36px] items-center px-[12px] py-[14px] hover:bg-[#f5f5f5] transition-colors"
                            >
                              {proofType === 'Passport' ? (
                                <div className="[word-break:break-word] font-['Mulish',sans-serif] font-normal leading-[0] text-[#231f20] text-[0px] whitespace-nowrap rounded-l-[8px]">
                                  <p className="leading-[1.452] mb-0 [text-align-last:justify] text-[13px]">Passport</p>
                                  <p className="leading-[1.452] text-[8px]">(For NRI nominees)</p>
                                </div>
                              ) : (
                                <p className="[word-break:break-word] font-['Mulish',sans-serif] font-normal leading-[normal] text-[#231f20] text-[13px] whitespace-nowrap">{proofType}</p>
                              )}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Mobile Number */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <p className="font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal text-[#231F20]">Mobile Number</p>
                      <div className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative flex focus-within:border-[var(--color-onboarding-primary)] focus-within:ring-2 focus-within:ring-[rgba(147,22,30,0.2)]">
                        <div className="bg-[#f5f5f5] flex gap-[4px] items-center px-[6px] rounded-l-[8px]">
                          <p className="font-['Mulish',sans-serif] font-normal text-[13px] text-[#71859b] w-[59px]">{nomineeMobileCountry}</p>
                          <svg className="h-[10px] w-[10px]" fill="none" viewBox="0 0 8.62789 4.87783">
                            <path d={nomineeFormSvgPaths.p3ea1e500} fill="#5A6B7D" />
                          </svg>
                        </div>
                        <Input
                          type="text"
                          value={nomineeMobile}
                          onChange={(e) => setNomineeMobile(e.target.value)}
                          placeholder="Enter Mobile Number"
                          className="h-full flex-1 border-0 bg-transparent px-[12px] shadow-none focus-visible:border-transparent focus-visible:ring-0"
                        />
                      </div>
                    </div>

                    {/* Email ID */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <p className="font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal text-[#231F20]">Email ID</p>
                      <Input
                        type="email"
                        value={nomineeEmail}
                        onChange={(e) => setNomineeEmail(e.target.value)}
                        placeholder="Enter Email ID"
                      />
                    </div>

                    {/* Is nominee a minor */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Is nominee a minor?</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <div className="flex gap-[30px] items-center">
                        {/* Yes/No Switcher */}
                        <div
                          className="bg-[#f5f5f5] rounded-[16777200px] p-[4px] flex gap-[4px] cursor-not-allowed"
                          title="This is set automatically from the nominee date of birth"
                        >
                          <button
                            type="button"
                            disabled
                            className={`px-[14px] py-[5px] rounded-[16777200px] cursor-not-allowed ${
                              nomineeIsMinor === 'yes' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                            }`}
                          >
                            <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Yes</p>
                          </button>
                          <button
                            type="button"
                            disabled
                            className={`px-[14px] py-[5px] rounded-[16777200px] cursor-not-allowed ${
                              nomineeIsMinor === 'no' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                            }`}
                          >
                            <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">No</p>
                          </button>
                        </div>

                        {/* DOB Field */}
                        <div className="flex-1">
                          <button
                            onClick={handleOpenDobPicker}
                            className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative w-full outline-none hover:bg-[#f9f9f9] transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)]"
                          >
                            <div className="flex items-center justify-between px-[14px] h-full gap-[8px]">
                              <div className="flex gap-[8px] flex-1 items-center font-['Mulish',sans-serif] font-normal text-[13px]">
                                <p className="text-[#71859b]">DOB</p>
                                <p className={nomineeDob ? 'text-[#231f20]' : 'text-[#71859b]'}>
                                  {nomineeDob || '00/00/0000'}
                                </p>
                              </div>
                              <svg className="size-[14px]" fill="none" viewBox="0 0 10.5 11.375">
                                <path d={nomineeFormSvgPaths.p3c25e700} fill="#231F20" />
                              </svg>
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Address */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <div className="flex items-center justify-between w-full">
                        <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                          <p className="text-[#231F20]">Address</p>
                          <p className="text-[#E8402F]">*</p>
                        </div>
                        <button onClick={handleOpenNomineeAddressModal} className="flex items-center gap-[4px] rounded-[6px] border border-transparent transition-opacity hover:opacity-70 focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0">
                          <svg className="size-[14px]" fill="none" viewBox="0 0 10.9379 10.9374">
                            <path d={nomineeFormSvgPaths.p2f5a1780} fill="#93161E" />
                          </svg>
                          <p className="font-['Mulish',sans-serif] font-normal leading-[18px] text-[#93161e] text-[12px]">Edit</p>
                        </button>
                      </div>
                      <div className={`${nomineeAddress ?'bg-[#f5f5f5]':'bg-white'} rounded-[8.75px] border border-[#e5e5e6] relative`}>
                        <div className={`flex items-center px-[14px] ${nomineeAddress ? 'py-[14px]' : 'py-[7px]'}`}>
                          <p className={`font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px] flex-1 overflow-hidden text-ellipsis ${nomineeAddress ? 'text-[#5a6b7d]' : 'text-[#71859b]'}`}>
                            {nomineeAddress || 'Enter Address'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Empty spacer for layout - maintains 3-column grid alignment */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] opacity-0 pointer-events-none"></div>

                    {/* Guardian Details - Only shown for minor nominees */}
                    {nomineeIsMinor === 'yes' && (
                      <>
                        {/* Divider Line */}
                        <div className="h-0 relative w-full">
                          <div className="absolute inset-[-1px_0]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1168 2">
                              <path d="M0 1H1168" stroke="#E5E5E6" strokeWidth="2" />
                            </svg>
                          </div>
                        </div>

                        {/* Guardian Details Header */}
                        <div className="flex flex-col font-['Mulish',sans-serif] font-medium gap-[4px] items-start justify-center w-full">
                          <p className="h-[22px] leading-[24px] overflow-hidden text-[#231f20] text-[16px] text-ellipsis w-full whitespace-nowrap">Guardian Details</p>
                          <p className="leading-[21px] text-[#435160] text-[14px] w-full">Required for Minor nominees</p>
                        </div>

                        {/* Guardian Name */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                          <div className="flex items-center justify-between w-full">
                            <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                              <p className="text-[#231F20]">Guardian Name</p>
                              <p className="text-[#E8402F]">*</p>
                            </div>
                            <span className="invisible font-['Mulish',sans-serif] font-normal leading-[18px] text-[12px]">Edit</span>
                          </div>
                          <Input
                            type="text"
                            value={guardianName}
                            onChange={(e) => setGuardianName(e.target.value)}
                            placeholder="Enter Guardian Name"
                            maxLength={NOMINEE_NAME_MAX_LENGTH}
                          />
                        </div>

                        {/* Guardian Address */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                          <div className="flex items-center justify-between w-full">
                            <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                              <p className="text-[#231F20]">Address</p>
                              <p className="text-[#E8402F]">*</p>
                            </div>
                            <button onClick={handleOpenGuardianAddressModal} className="flex items-center gap-[4px] rounded-[6px] border border-transparent transition-opacity hover:opacity-70 focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0">
                              <svg className="size-[14px]" fill="none" viewBox="0 0 10.9379 10.9374">
                                <path d={nomineeFormSvgPaths.p2f5a1780} fill="#93161E" />
                              </svg>
                              <p className="font-['Mulish',sans-serif] font-normal leading-[18px] text-[#93161e] text-[12px]">Edit</p>
                            </button>
                          </div>
                          <div className={`${guardianAddress ?'bg-[#f5f5f5]':'bg-white'}  rounded-[8.75px] border border-[#e5e5e6] relative`}>
                            <div className={`flex items-center px-[14px] ${guardianAddress ? 'py-[14px]' : 'py-[7px]'}`}>
                              <p className={`font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px] flex-1 overflow-hidden text-ellipsis ${guardianAddress ? 'text-[#5a6b7d]' : 'text-[#71859b]'}`}>
                                {guardianAddress || 'Enter Address'}
                              </p>
                            </div>
                          </div>
                          <label className="flex items-center gap-2 pt-[4px]">
                            <Checkbox
                              checked={sameAsNomineeAddress}
                              className="border-[#eeeeee] data-[state=checked]:border-[#93161E] data-[state=checked]:bg-[#93161E] data-[state=checked]:text-white"
                              onCheckedChange={(checked) => {
                                onSameAsNomineeAddressChange(Boolean(checked));
                              }}
                            />
                            <span className="font-['Mulish',sans-serif] text-[14px] font-normal leading-none tracking-normal text-[#435160]">
                              Same as nominee address
                            </span>
                          </label>
                        </div>

                        {/* Empty spacer for layout - maintains 3-column grid alignment */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] opacity-0 pointer-events-none"></div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
            </div>
          </div>
      </div>

      {/* Mobile/Tablet View */}
      <div className="lg:hidden">
        <div className="flex flex-col gap-[24px]">
          {/* Header */}
          <div className="flex flex-col gap-[4px]">
            <p className="font-['Mulish',sans-serif] font-medium leading-[28px] md:leading-[33px] text-[#231f20] text-[20px] md:text-[22px]">Nominee Details</p>
            <p className="font-['Mulish',sans-serif] font-normal leading-[20px] md:leading-[22.5px] text-[#435160] text-[14px] md:text-[15px]">{fetchedDetailsSubtitle}</p>
          </div>

          {/* Form Container */}
          <div className="flex flex-col gap-[8px]">
            {/* Step Progress */}
            <div className="flex items-center justify-between font-['Mulish',sans-serif] font-normal leading-[18px] text-[#231f20] text-[12px]">
              <p>Step 4 of 6</p>
              <p>60%</p>
            </div>

            {/* White Card */}
            <div className="w-full overflow-visible rounded-[16px] bg-white shadow-[0px_0px_12px_0px_rgba(0,0,0,0.06)]">
              {/* Progress Bar - Full width at top */}
              <div className="h-2 w-full overflow-hidden rounded-t-[16px] bg-[#e6e7e8]">
                <div className="h-full w-[60%] rounded-r-full bg-[#37b400]" />
              </div>

              <div className="flex flex-col gap-[20px] p-[16px] pb-0">
                {/* Switcher */}
                <div className="flex items-start w-full">
                  <div className="bg-[#f5f5f5] rounded-[16777200px] p-[4px] flex gap-[4px]">
                    <button
                      onClick={() => setNomineeOption('later')}
                      className={`px-[14px] py-[5px] rounded-[16777200px] border border-transparent transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0 ${
                        nomineeOption === 'later' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                      }`}
                    >
                      <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Add Nominee Later</p>
                    </button>
                    <button
                      onClick={() => setNomineeOption('now')}
                      className={`px-[14px] py-[5px] rounded-[16777200px] border border-transparent transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0 ${
                        nomineeOption === 'now' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                      }`}
                    >
                      <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Add Nominee now</p>
                    </button>
                  </div>
                </div>
              </div>

              {/* Content Area */}
              <div className="p-[16px] pt-[20px]">
                {/* Conditional Content */}
                {nomineeOption === 'later' ? (
                  /* Empty State */
                  <div className="flex flex-col items-center justify-center py-[24px] gap-[12px]">
                    <img src={imgEmptyNominee} alt="No nominee added" className="w-[108px] h-[66px] object-contain" />
                    <p className="font-['Mulish',sans-serif] font-normal leading-none text-[#71859B] text-[14px] text-center tracking-[0px]">Add a nominee now for convenience or complete this step later.</p>
                  </div>
                ) : (
                  /* Nominee Form */
                  <div className="flex flex-wrap gap-[16px]">
                    {/* Nominee Name */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Nominee Name</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <Input
                        type="text"
                        value={nomineeName}
                        onChange={(e) => setNomineeName(e.target.value)}
                        placeholder="Enter Nominee Name"
                        maxLength={NOMINEE_NAME_MAX_LENGTH}
                        autoComplete="name"
                        inputMode="text"
                      />
                    </div>

                    <RelationshipField
                      value={nomineeRelationship}
                      onChange={setNomineeRelationship}
                    />

                    {/* Proof of Identity */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] relative" ref={proofDropdownMobileRef}>
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Proof of Identity</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <div className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative flex items-center focus-within:border-[var(--color-onboarding-primary)] focus-within:ring-2 focus-within:ring-[rgba(147,22,30,0.2)]">
                        <button
                          onClick={() => setShowProofDropdown(!showProofDropdown)}
                          tabIndex={-1}
                          className="bg-[#f5f5f5] flex gap-[4px] items-center px-[6px] h-full outline-none hover:bg-[#e8e8e8] transition-colors focus-visible:outline-none  rounded-l-[8px]"
                        >
                          <p className="font-['Mulish',sans-serif] font-normal text-[13px] text-[#71859b]">{nomineeProofType}</p>
                          <svg className="h-[10px] w-[10px]" fill="none" viewBox="0 0 8.62789 4.87783">
                            <path d={nomineeFormSvgPaths.p3ea1e500} fill="#5A6B7D" />
                          </svg>
                        </button>
                        <Input
                          type="text"
                          value={nomineeProofNumber}
                          onChange={(e) => setNomineeProofNumber(e.target.value)}
                          placeholder={proofNumberPlaceholder}
                          maxLength={proofNumberMaxLength}
                          inputMode={isAadhaarProof ? 'numeric' : 'text'}
                          autoCapitalize={isAadhaarProof ? 'off' : 'characters'}
                          className={`h-full flex-1 border-0 bg-transparent px-[12px] shadow-none focus-visible:border-transparent focus-visible:ring-0 ${isAadhaarProof ? '' : 'uppercase'}`}
                        />
                      </div>

                      {/* Dropdown Menu */}
                      {showProofDropdown && (
                        <div
                          className="absolute top-[calc(100%+4px)] left-0 right-0 bg-white rounded-[8px] border border-[#e5e5e6] z-[60] overflow-hidden shadow-lg"
                          onMouseDown={(event) => event.stopPropagation()}
                        >
                          {PROOF_OF_IDENTITY_OPTIONS.map((proofType) => (
                            <button
                              key={proofType}
                              onClick={() => {
                                setNomineeProofType(proofType);
                                setShowProofDropdown(false);
                              }}
                              className="content-stretch w-full flex gap-[8px] h-[36px] items-center px-[12px] py-[14px] hover:bg-[#f5f5f5] transition-colors"
                            >
                              {proofType === 'Passport' ? (
                                <div className="[word-break:break-word] text-justify font-['Mulish',sans-serif] font-normal leading-[0] text-[#231f20] text-[0px] whitespace-nowrap">
                                  <p className="leading-[1.452] mb-0 text-[13px]">Passport</p>
                                  <p className="leading-[1.452] text-[8px]">(For NRI nominees)</p>
                                </div>
                              ) : (
                                <p className="[word-break:break-word] font-['Mulish',sans-serif] font-normal leading-[normal] text-[#231f20] text-[13px] whitespace-nowrap">{proofType}</p>
                              )}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Mobile Number */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                      <p className="font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal text-[#231F20]">Mobile Number</p>
                      <div className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative flex focus-within:border-[var(--color-onboarding-primary)] focus-within:ring-2 focus-within:ring-[rgba(147,22,30,0.2)]">
                        <div className="bg-[#f5f5f5] flex gap-[4px] items-center px-[6px] rounded-l-[8px]">
                          <p className="font-['Mulish',sans-serif] font-normal text-[13px] text-[#71859b] w-[59px]">{nomineeMobileCountry}</p>
                          <svg className="h-[10px] w-[10px]" fill="none" viewBox="0 0 8.62789 4.87783">
                            <path d={nomineeFormSvgPaths.p3ea1e500} fill="#5A6B7D" />
                          </svg>
                        </div>
                        <Input
                          type="text"
                          value={nomineeMobile}
                          onChange={(e) => setNomineeMobile(e.target.value)}
                          placeholder="Enter Mobile Number"
                          className="h-full flex-1 border-0 bg-transparent px-[12px] shadow-none focus-visible:border-transparent focus-visible:ring-0"
                        />
                      </div>
                    </div>

                    {/* Email ID */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                      <p className="font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal text-[#231F20]">Email ID</p>
                      <Input
                        type="email"
                        value={nomineeEmail}
                        onChange={(e) => setNomineeEmail(e.target.value)}
                        placeholder="Enter Email ID"
                      />
                    </div>

                    {/* Is nominee a minor */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                      <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                        <p className="text-[#231F20]">Is nominee a minor?</p>
                        <p className="text-[#E8402F]">*</p>
                      </div>
                      <div className="flex gap-[30px] items-center">
                        {/* Yes/No Switcher */}
                        <div
                          className="bg-[#f5f5f5] rounded-[16777200px] p-[4px] flex gap-[4px] cursor-not-allowed"
                          title="This is set automatically from the nominee date of birth"
                        >
                          <button
                            type="button"
                            disabled
                            className={`px-[14px] py-[5px] rounded-[16777200px] cursor-not-allowed ${
                              nomineeIsMinor === 'yes' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                            }`}
                          >
                            <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">Yes</p>
                          </button>
                          <button
                            type="button"
                            disabled
                            className={`px-[14px] py-[5px] rounded-[16777200px] cursor-not-allowed ${
                              nomineeIsMinor === 'no' ? 'bg-white text-[#93161e]' : 'text-[#5a6b7d]'
                            }`}
                          >
                            <p className="font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px]">No</p>
                          </button>
                        </div>

                        {/* DOB Field */}
                        <div className="flex-1">
                          <button
                            onClick={handleOpenDobPicker}
                            className="bg-white h-[36px] rounded-[8px] border border-[#eee] relative w-full outline-none hover:bg-[#f9f9f9] transition-colors focus-visible:border-[var(--color-onboarding-primary)] focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)]"
                          >
                            <div className="flex items-center justify-between px-[14px] h-full gap-[8px]">
                              <div className="flex gap-[8px] flex-1 items-center font-['Mulish',sans-serif] font-normal text-[13px]">
                                <p className="text-[#71859b]">DOB</p>
                                <p className={nomineeDob ? 'text-[#231f20]' : 'text-[#71859b]'}>
                                  {nomineeDob || '00/00/0000'}
                                </p>
                              </div>
                              <svg className="size-[14px]" fill="none" viewBox="0 0 10.5 11.375">
                                <path d={nomineeFormSvgPaths.p3c25e700} fill="#231F20" />
                              </svg>
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Address */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] max-w-[calc(33.333%-11px)]">
                      <div className="flex items-center justify-between w-full">
                        <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                          <p className="text-[#231F20]">Address</p>
                          <p className="text-[#E8402F]">*</p>
                        </div>
                        <button onClick={handleOpenNomineeAddressModal} className="flex items-center gap-[4px] rounded-[6px] border border-transparent transition-opacity hover:opacity-70 focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0">
                          <svg className="size-[14px]" fill="none" viewBox="0 0 10.9379 10.9374">
                            <path d={nomineeFormSvgPaths.p2f5a1780} fill="#93161E" />
                          </svg>
                          <p className="font-['Mulish',sans-serif] font-normal leading-[18px] text-[#93161e] text-[12px]">Edit</p>
                        </button>
                      </div>
                      <div className={`${nomineeAddress ?'bg-[#f5f5f5]':'bg-white'}  rounded-[8.75px] border border-[#e5e5e6] relative`}>
                        <div className={`flex items-center px-[14px]  ${nomineeAddress ? 'py-[14px]' : 'py-[7px]'}`}>
                          <p className={`font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px] flex-1 overflow-hidden text-ellipsis ${nomineeAddress ? 'text-[#5a6b7d]' : 'text-[#71859b]'}`}>
                            {nomineeAddress || 'Enter Address'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Empty spacer for layout - maintains 3-column grid alignment */}
                    <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] opacity-0 pointer-events-none"></div>

                    {/* Guardian Details - Only shown for minor nominees */}
                    {nomineeIsMinor === 'yes' && (
                      <>
                        {/* Divider Line */}
                        <div className="h-0 relative w-full">
                          <div className="absolute inset-[-1px_0]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1168 2">
                              <path d="M0 1H1168" stroke="#E5E5E6" strokeWidth="2" />
                            </svg>
                          </div>
                        </div>

                        {/* Guardian Details Header */}
                        <div className="flex flex-col font-['Mulish',sans-serif] font-medium gap-[4px] items-start justify-center w-full">
                          <p className="h-[22px] leading-[24px] overflow-hidden text-[#231f20] text-[16px] text-ellipsis w-full whitespace-nowrap">Guardian Details</p>
                          <p className="leading-[21px] text-[#435160] text-[14px] w-full">Required for Minor nominees</p>
                        </div>

                        {/* Guardian Name */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                          <div className="flex items-center justify-between w-full">
                            <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                              <p className="text-[#231F20]">Guardian Name</p>
                              <p className="text-[#E8402F]">*</p>
                            </div>
                            <span className="invisible font-['Mulish',sans-serif] font-normal leading-[18px] text-[12px]">Edit</span>
                          </div>
                          <Input
                            type="text"
                            value={guardianName}
                            onChange={(e) => setGuardianName(e.target.value)}
                            placeholder="Enter Guardian Name"
                            maxLength={NOMINEE_NAME_MAX_LENGTH}
                          />
                        </div>

                        {/* Guardian Address */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px]">
                          <div className="flex items-center justify-between w-full">
                            <div className="flex gap-[2px] items-center font-['Mulish',sans-serif] text-[12px] font-normal leading-none tracking-normal">
                              <p className="text-[#231F20]">Address</p>
                              <p className="text-[#E8402F]">*</p>
                            </div>
                            <button onClick={handleOpenGuardianAddressModal} className="flex items-center gap-[4px] rounded-[6px] border border-transparent transition-opacity hover:opacity-70 focus-visible:border-[var(--color-onboarding-primary)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[rgba(147,22,30,0.2)] focus-visible:ring-offset-0">
                              <svg className="size-[14px]" fill="none" viewBox="0 0 10.9379 10.9374">
                                <path d={nomineeFormSvgPaths.p2f5a1780} fill="#93161E" />
                              </svg>
                              <p className="font-['Mulish',sans-serif] font-normal leading-[18px] text-[#93161e] text-[12px]">Edit</p>
                            </button>
                          </div>
                          <div className={`${guardianAddress ?'bg-[#f5f5f5]':'bg-white'}  rounded-[8.75px] border border-[#e5e5e6] relative`}>
                            <div className={`flex items-center px-[14px] ${guardianAddress ? 'py-[14px]' : 'py-[7px]'}`}>
                              <p className={`font-['Mulish',sans-serif] font-normal leading-[19.5px] text-[13px] flex-1 overflow-hidden text-ellipsis ${guardianAddress ? 'text-[#5a6b7d]' : 'text-[#71859b]'}`}>
                                {guardianAddress || 'Enter Address'}
                              </p>
                            </div>
                          </div>
                          <label className="flex items-center gap-2 pt-[4px]">
                            <Checkbox
                              checked={sameAsNomineeAddress}
                              className="border-[#eeeeee] data-[state=checked]:border-[#93161E] data-[state=checked]:bg-[#93161E] data-[state=checked]:text-white"
                              onCheckedChange={(checked) => {
                                onSameAsNomineeAddressChange(Boolean(checked));
                              }}
                            />
                            <span className="font-['Mulish',sans-serif] text-[14px] font-normal leading-none tracking-normal text-[#435160]">
                              Same as nominee address
                            </span>
                          </label>
                        </div>

                        {/* Empty spacer for layout - maintains 3-column grid alignment */}
                        <div className="flex flex-col gap-[4px] flex-1 min-w-[310px] opacity-0 pointer-events-none"></div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <OnboardingStepFooter
        nextLabel="Upload Documents"
        nextClickable={isEditMode}
        onNextClick={() => {
          if (!canProceed) {
            return;
          }
          setIsTransitioning(true);
          setTimeout(() => {
            setCurrentStep('upload-documents');
            setTimeout(() => setIsTransitioning(false), 50);
          }, 300);
        }}
        showPrevious={!isEditMode}
        onPrevious={() => {
          setIsTransitioning(true);
          setTimeout(() => {
            setCurrentStep('bank-details');
            setTimeout(() => setIsTransitioning(false), 50);
          }, 300);
        }}
        continueLabel={isEditMode ? 'Go to Review' : 'Continue'}
        continueDisabled={!canProceed}
        isLoading={isTransitioning}
        loadingLabel="Saving..."
        onContinue={() => {
          if (!canProceed || isTransitioning) {
            return;
          }
          setIsTransitioning(true);
          setTimeout(() => {
            if (isEditMode) {
              setCurrentStep('review-confirm');
              setIsEditMode(false);
            } else {
              setCurrentStep('upload-documents');
            }
            setTimeout(() => setIsTransitioning(false), 50);
          }, 300);
        }}
      />

      {/* DOB Picker Modal */}
      {showDobPicker && (
        <>
          {/* Backdrop + scroll container */}
          <div
            className={`fixed inset-0 backdrop-blur-[3px] bg-[rgba(35,31,32,0.5)] z-40 overflow-y-auto transition-opacity duration-200 ease-out ${
              dobPickerAnimating ? 'opacity-100' : 'opacity-0'
            }`}
            onClick={handleCloseDobPicker}
          >
          <div className="flex min-h-full items-center justify-center p-[20px]">
          {/* Modal */}
          <div className={`bg-white rounded-[16px] shadow-[4px_4px_20px_0px_rgba(0,0,0,0.12)] w-full max-w-[480px] flex flex-col transition-transform duration-200 ease-out overflow-hidden ${
            dobPickerAnimating ? 'scale-100' : 'scale-95'
          }`} onClick={(e) => e.stopPropagation()}>
            <div className="flex flex-col gap-[24px] p-[24px]">
              {/* Header */}
              <div className="flex items-center justify-between w-full">
                <p className="font-['Mulish',sans-serif] font-medium leading-[33px] text-[#435160] text-[22px]">Select Date of Birth</p>
                <button
                  onClick={handleCloseDobPicker}
                  className="size-[15px] flex items-center justify-center hover:opacity-70 transition-opacity duration-200 shrink-0"
                >
                  <svg className="size-full" fill="none" viewBox="0 0 15.0008 15.0008">
                    <path d={emailOtpSvgPaths.p3bbf7480} fill="#435160" />
                  </svg>
                </button>
              </div>

              {/* Date Selectors */}
              <div className="flex gap-[12px]">
                <DobSelect
                  label="Day"
                  value={selectedDay}
                  onChange={setSelectedDay}
                  options={getDobDayOptions(selectedYear, selectedMonth)}
                />
                <DobSelect
                  label="Month"
                  value={selectedMonth}
                  onChange={setSelectedMonth}
                  options={getDobMonthOptions(selectedYear)}
                />
                <DobSelect
                  label="Year"
                  value={selectedYear}
                  onChange={setSelectedYear}
                  options={getDobYearOptions()}
                />
              </div>

              {/* Save Button */}
              <button
                onClick={handleSaveDob}
                className="bg-[#93161e] hover:bg-[#7a1319] h-[44px] rounded-[8px] flex items-center justify-center transition-colors"
              >
                <p className="font-['Mulish',sans-serif] font-normal text-[14px] text-white">Save</p>
              </button>
            </div>
          </div>
          </div>
          </div>
        </>
      )}

    </>
  );
}
